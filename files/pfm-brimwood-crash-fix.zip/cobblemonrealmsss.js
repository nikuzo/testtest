console.info('Hello Cobblemon Realms Player! (Loaded startup scripts)')

StartupEvents.registry('item', event => {

  //Cobblemon Realms
  event.create('realms_coin').displayName('Realms Coin').rarity('Epic')


})

ItemEvents.modification(event => {

})

// Bug del propio Paladin's Furniture Mod: este item concreto (herringbone de Brimwood,
// compat con Regions Unexplored) tira ArrayIndexOutOfBoundsException al renderizar su icono
// (crashea a jugadores al buscar en el inventario creativo). Sin fix oficial disponible,
// lo quitamos de la pestaña creativa para que nadie lo pueda ver ni obtener por accidente.
StartupEvents.modifyCreativeTab('pfm:furniture', event => {
  event.remove('pfm:brimwood_regions_unexplored_herringbone_planks')
})

StartupEvents.postInit(event => { Platform.mods.kubejs.name = 'Cobblemon Realms'; });
