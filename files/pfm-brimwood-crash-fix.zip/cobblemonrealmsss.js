console.info('Hello Cobblemon Realms Player! (Loaded startup scripts)')

StartupEvents.registry('item', event => {

  //Cobblemon Realms
  event.create('realms_coin').displayName('Realms Coin').rarity('Epic')


})

ItemEvents.modification(event => {

})

// Bug del propio Paladin's Furniture Mod: este item concreto (herringbone de Brimwood,
// compat con Regions Unexplored) tira ArrayIndexOutOfBoundsException al renderizar su icono
// (crashea a jugadores al buscar en el inventario creativo). Sin fix oficial disponible,
// lo quitamos de la pestaña creativa para que nadie lo pueda ver ni obtener por accidente.
const BRIMWOOD_HERRINGBONE = 'pfm:brimwood_regions_unexplored_herringbone_planks'

// PFM añade sus bloques tanto a su propia pestaña "pfm:furniture" como a pestañas vanilla
// (p.ej. Bloques de Construcción), y la pestaña de Buscar agrega de TODAS las pestañas.
// Hay que quitarlo de cada sitio donde pueda aparecer, no solo de la pestaña de PFM.
;['pfm:furniture', 'minecraft:building_blocks', 'minecraft:functional_blocks', 'minecraft:search'].forEach(tabId => {
  StartupEvents.modifyCreativeTab(tabId, event => {
    console.info('[BrimwoodFix] modifyCreativeTab ' + tabId + ' is running')
    event.removeFromParent(BRIMWOOD_HERRINGBONE)
    event.removeFromSearch(BRIMWOOD_HERRINGBONE)
    event.remove(BRIMWOOD_HERRINGBONE)
    console.info('[BrimwoodFix] removal calls done for ' + tabId)
  })
})

StartupEvents.postInit(event => { Platform.mods.kubejs.name = 'Cobblemon Realms'; });
